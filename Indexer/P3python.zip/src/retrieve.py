# import package ...
import sys
import gzip
import json


def buildIndex(inputFile):
    # Your function start here ...
    return


def runQueries(index, queriesFile, outputFile):
    return


if __name__ == '__main__':
    # Read arguments from command line, or use sane defaults for IDE.
    argv_len = len(sys.argv)
    inputFile = sys.argv[1] if argv_len >= 2 else "sciam.json.gz"
    queriesFile = sys.argv[2] if argv_len >= 3 else "trainQueries.tsv"
    outputFile = sys.argv[3] if argv_len >= 4 else "trainQueries.trecrun"

    index = buildIndex(inputFile)
    if queriesFile == 'showIndex':
        # Invoke your debug function here (Optional)
    elif queriesFile == 'showTerms':
        # Invoke your debug function here (Optional)
    else:
        runQueries(index, queriesFile, outputFile)

    # Feel free to change anything
